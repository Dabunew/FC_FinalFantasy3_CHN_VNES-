//////////////////////////////////////////////////////////////////////////
//                                                                      //
//      NES Pad                                                         //
//                                                           Norix      //
//                                               written     2001/02/22 //
//                                               last modify ----/--/-- //
//////////////////////////////////////////////////////////////////////////
#define	WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "typedef.h"
#include "macro.h"

#include "Config.h"

#include "DirectDraw.h"
#include "DirectInput.h"

#include "nes.h"
#include "pad.h"
#include "rom.h"

PAD::PAD( NES* parent ) : nes( parent )
{
	excontroller_select = 0;
	bStrobe = FALSE;

	padbit[0] = padbit[1] = padbit[2] = padbit[3] = 0;
	micbit = 0;
}

PAD::~PAD()
{
	DirectDraw.SetZapperMode( FALSE );
	DirectDraw.SetZapperDrawMode( FALSE );
}

void	PAD::Reset()
{
	pad1bit = pad2bit = 0;
	bStrobe = FALSE;

	bZapperMode = FALSE;

	ZeroMemory( padcnt, sizeof(padcnt) );

}


DWORD	PAD::GetSyncData()
{
DWORD	ret;

	ret = (DWORD)padbit[0]|((DWORD)padbit[1]<<8)|((DWORD)padbit[2]<<16)|((DWORD)padbit[3]<<24);
	ret |= (DWORD)micbit<<8;

	return	ret;
}

void	PAD::SetSyncData( DWORD data )
{
	micbit = (BYTE)((data&0x00000400)>>8);
	padbit[0] = (BYTE) data;
	padbit[1] = (BYTE)(data>> 8);
	padbit[2] = (BYTE)(data>>16);
	padbit[3] = (BYTE)(data>>24);
}


void	PAD::Sync()
{
	padbit[0] = SyncSub( 0 );
	padbit[1] = SyncSub( 1 );
	padbit[2] = SyncSub( 2 );
	padbit[3] = SyncSub( 3 );

	// Mic
	micbit = 0;
	if( Config.controller.nButton[1][10] && DirectInput.m_Sw[Config.controller.nButton[1][10]]
	 || Config.controller.nButton[1][26] && DirectInput.m_Sw[Config.controller.nButton[1][26]] ) {
		micbit |= 0x04;
	}

	// For NSF
	NsfSub();
}

static	INT	ren30fps[] = {
	1, 0
};
static	INT	ren20fps[] = {
	1, 1, 0
};
static	INT	ren15fps[] = {
	1, 1, 0, 0
};
static	INT	ren10fps[] = {
	1, 1, 1, 0, 0, 0
};

static	INT	renmask[] = {
	6, 4, 3, 2,
};
static	INT*	rentbl[] = {
	ren10fps, ren15fps, ren20fps, ren30fps
};

BYTE	PAD::SyncSub( INT no )
{
WORD	bit = 0;

	// Up
	if( Config.controller.nButton[no][ 0] && DirectInput.m_Sw[Config.controller.nButton[no][ 0]]
	 || Config.controller.nButton[no][16] && DirectInput.m_Sw[Config.controller.nButton[no][16]] )
		bit |= 1<<4;
	// Down
	if( Config.controller.nButton[no][ 1] && DirectInput.m_Sw[Config.controller.nButton[no][ 1]]
	 || Config.controller.nButton[no][17] && DirectInput.m_Sw[Config.controller.nButton[no][17]] )
		bit |= 1<<5;
	// Left
	if( Config.controller.nButton[no][ 2] && DirectInput.m_Sw[Config.controller.nButton[no][ 2]]
	 || Config.controller.nButton[no][18] && DirectInput.m_Sw[Config.controller.nButton[no][18]] )
		bit |= 1<<6;
	// Right
	if( Config.controller.nButton[no][ 3] && DirectInput.m_Sw[Config.controller.nButton[no][ 3]]
	 || Config.controller.nButton[no][19] && DirectInput.m_Sw[Config.controller.nButton[no][19]] )
		bit |= 1<<7;

	// ��ֹͬ�r����
	if( (bit&((1<<4)|(1<<5))) == ((1<<4)|(1<<5)) )
		bit &= ~((1<<4)|(1<<5));
	if( (bit&((1<<6)|(1<<7))) == ((1<<6)|(1<<7)) )
		bit &= ~((1<<6)|(1<<7));

	// A,B
	if( Config.controller.nButton[no][ 4] && DirectInput.m_Sw[Config.controller.nButton[no][ 4]]
	 || Config.controller.nButton[no][20] && DirectInput.m_Sw[Config.controller.nButton[no][20]] )
		bit |= 1<<0;
	if( Config.controller.nButton[no][ 5] && DirectInput.m_Sw[Config.controller.nButton[no][ 5]]
	 || Config.controller.nButton[no][21] && DirectInput.m_Sw[Config.controller.nButton[no][21]] )
		bit |= 1<<1;

	// A,B Rapid
	if( Config.controller.nButton[no][ 6] && DirectInput.m_Sw[Config.controller.nButton[no][ 6]]
	 || Config.controller.nButton[no][22] && DirectInput.m_Sw[Config.controller.nButton[no][22]] )
		bit |= 1<<8;
	if( Config.controller.nButton[no][ 7] && DirectInput.m_Sw[Config.controller.nButton[no][ 7]]
	 || Config.controller.nButton[no][23] && DirectInput.m_Sw[Config.controller.nButton[no][23]] )
		bit |= 1<<9;

	// Start, Select
	if( Config.controller.nButton[no][ 8] && DirectInput.m_Sw[Config.controller.nButton[no][ 8]]
	 || Config.controller.nButton[no][24] && DirectInput.m_Sw[Config.controller.nButton[no][24]] )
		bit |= 1<<2;
	if( Config.controller.nButton[no][ 9] && DirectInput.m_Sw[Config.controller.nButton[no][ 9]]
	 || Config.controller.nButton[no][25] && DirectInput.m_Sw[Config.controller.nButton[no][25]] )
		bit |= 1<<3;

	// A rapid setup
	if( bit&(1<<8) ) {
		INT	spd = Config.controller.nRapid[no][0];
		if( spd >= 3 ) spd = 3;
		INT*	tbl = rentbl[spd];

		if( padcnt[no][0] >= renmask[spd] )
			padcnt[no][0] = 0;

		if( tbl[padcnt[no][0]] )
			bit |= (1<<0);
		else
			bit &= ~(1<<0);

		padcnt[no][0]++;
	} else {
		padcnt[no][0] = 0;
	}
	// B rapid setup
	if( bit&(1<<9) ) {
		INT	spd = Config.controller.nRapid[no][1];
		if( spd >= 3 ) spd = 3;
		INT*	tbl = rentbl[spd];

		if( padcnt[no][1] >= renmask[spd] )
			padcnt[no][1] = 0;

		if( tbl[padcnt[no][1]] )
			bit |= (1<<1);
		else
			bit &= ~(1<<1);

		padcnt[no][1]++;
	} else {
		padcnt[no][1] = 0;
	}

	return	(BYTE)(bit&0xFF);
}

void	PAD::Strobe()
{
	if( Config.emulator.bFourPlayer ) {
	// NES type
		pad1bit = (DWORD)padbit[0] | ((DWORD)padbit[2]<<8) | 0x00080000;
		pad2bit = (DWORD)padbit[1] | ((DWORD)padbit[3]<<8) | 0x00040000;
	} else {
	// Famicom type
		pad1bit = (DWORD)padbit[0];
		pad2bit = (DWORD)padbit[1];
	}
	pad3bit = (DWORD)padbit[2];
	pad4bit = (DWORD)padbit[3];
}

BYTE	PAD::Read( WORD addr )
{
BYTE	data = 0x00;

	if( addr == 0x4016 ) {
		data = (BYTE)pad1bit&1;
		pad1bit>>=1;
		data |= ((BYTE)pad3bit&1)<<1;
		pad3bit>>=1;
		// Mic
		data |= micbit;

	}
	if( addr == 0x4017 ) {
		data = (BYTE)pad2bit&1;
		pad2bit>>=1;
		data |= ((BYTE)pad4bit&1)<<1;
		pad4bit>>=1;

	}

	return	data;
}

void	PAD::Write( WORD addr, BYTE data )
{
	if( addr == 0x4016 ) {
		if( data&0x01 ) {
			bStrobe = TRUE;
		} else if( bStrobe ) {
			bStrobe = FALSE;

			Strobe();
		}

	}
	if( addr == 0x4017 ) {
	}
}

void	PAD::NsfSub()
{
	nsfbit = 0;

	// Play
	if( Config.controller.nNsfButton[ 0] && DirectInput.m_Sw[Config.controller.nNsfButton[ 0]]
	 || Config.controller.nNsfButton[16] && DirectInput.m_Sw[Config.controller.nNsfButton[16]] )
		nsfbit |= 1<<0;
	// Stop
	if( Config.controller.nNsfButton[ 1] && DirectInput.m_Sw[Config.controller.nNsfButton[ 1]]
	 || Config.controller.nNsfButton[17] && DirectInput.m_Sw[Config.controller.nNsfButton[17]] )
		nsfbit |= 1<<1;

	// Number -1
	if( Config.controller.nNsfButton[ 2] && DirectInput.m_Sw[Config.controller.nNsfButton[ 2]]
	 || Config.controller.nNsfButton[18] && DirectInput.m_Sw[Config.controller.nNsfButton[18]] )
		nsfbit |= 1<<2;
	// Number +1
	if( Config.controller.nNsfButton[ 3] && DirectInput.m_Sw[Config.controller.nNsfButton[ 3]]
	 || Config.controller.nNsfButton[19] && DirectInput.m_Sw[Config.controller.nNsfButton[19]] )
		nsfbit |= 1<<3;
	// Number +16
	if( Config.controller.nNsfButton[ 4] && DirectInput.m_Sw[Config.controller.nNsfButton[ 4]]
	 || Config.controller.nNsfButton[20] && DirectInput.m_Sw[Config.controller.nNsfButton[20]] )
		nsfbit |= 1<<4;
	// Number -16
	if( Config.controller.nNsfButton[ 5] && DirectInput.m_Sw[Config.controller.nNsfButton[ 5]]
	 || Config.controller.nNsfButton[21] && DirectInput.m_Sw[Config.controller.nNsfButton[21]] )
		nsfbit |= 1<<5;

	// ��ֹͬ�r����
	if( (nsfbit&((1<<2)|(1<<3))) == ((1<<2)|(1<<3)) )
		nsfbit &= ~((1<<2)|(1<<3));
	if( (nsfbit&((1<<4)|(1<<5))) == ((1<<4)|(1<<5)) )
		nsfbit &= ~((1<<4)|(1<<5));
}



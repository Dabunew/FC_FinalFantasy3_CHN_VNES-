#ifndef	__STATE_INCLUDED__
#define	__STATE_INCLUDED__

#pragma pack( push, 1 )

typedef	struct	tagFILEHDR {	//  0123456789AB
	BYTE	ID[12];		// "VirtuaNES ST"
	WORD	Reserved;
	WORD	BlockVersion;
} FILEHDR, *LPFILEHDR;

// VirtuaNES version0.30�Խ���
typedef	struct	tagFILEHDR2 {	//  0123456789AB
	BYTE	ID[12];		// "VirtuaNES ST"
	WORD	Reserved;
	WORD	BlockVersion;	// 0x0200 / 0x0210(v0.60�ȍ~)

	DWORD	Ext0;		// ROM:Program CRC	FDS:Program ID
	WORD	Ext1;		// ROM:����		FDS:Maker ID
	WORD	Ext2;		// ROM:����		FDS:Diskö��
	LONG	MovieStep;	// ׷ӛ(ȡ��ֱ��)Movie�r��Frame��
	LONG	MovieOffset;	// ׷ӛ(ȡ��ֱ��)Movie�r��File Offset
} FILEHDR2, *LPFILEHDR2;

typedef	struct	tagBLOCKHDR {
	BYTE	ID[8];
	WORD	Reserved;
	WORD	BlockVersion;
	DWORD	BlockSize;
} BLOCKHDR, *LPBLOCKHDR;

// CPU Register
// version 0x0110�ޤ�
typedef	struct	tagCPUSTAT_O {
	WORD	PC;
	BYTE	A;
	BYTE	X;
	BYTE	Y;
	BYTE	S;
	BYTE	P;
	BYTE	I;	// Interrupt pending flag

	BYTE	FrameIRQ;
	BYTE	reserved[3];

	LONG	mod_cycles;	// Movie�Ȥ�Clock����΢��ʤ���������

	// version 0x0110
	SQWORD	emul_cycles;
	SQWORD	base_cycles;
} CPUSTAT_O, *LPCPUSTAT_O;

// version 0x0200
typedef	struct	tagCPUSTAT {
	WORD	PC;
	BYTE	A;
	BYTE	X;
	BYTE	Y;
	BYTE	S;
	BYTE	P;
	BYTE	I;	// Interrupt pending flag

	BYTE	FrameIRQ;
	BYTE	FrameIRQ_occur;
	BYTE	reserved[2];
	LONG	FrameIRQ_cycles;

	LONG	DMA_cycles;

	SQWORD	emul_cycles;
	SQWORD	base_cycles;
} CPUSTAT, *LPCPUSTAT;

// PPU Register
typedef	struct	tagPPUSTAT {
	BYTE	reg0;
	BYTE	reg1;
	BYTE	reg2;
	BYTE	reg3;
	BYTE	reg7;
	BYTE	toggle56;

	WORD	loopy_t;
	WORD	loopy_v;
	WORD	loopy_x;
} PPUSTAT, *LPPPUSTAT;

// APU Register(����Sound����)
typedef	struct	tagAPUSTAT_O {
	BYTE	reg[0x0018];
	BYTE	ext[0x0100];
} APUSTAT_O, *LPAPUSTAT_O;

// Controler Register
typedef	struct	tagCTRREG {
	DWORD	pad1bit;
	DWORD	pad2bit;
	DWORD	pad3bit;
	DWORD	pad4bit;
	BYTE	strobe;
} CTRREG, *LPCTRREG;

//
// Register Data
// ID "REG DATA"
// ver 0x0110�܂�
typedef	struct	tagREGSTAT_O {
	union	uniCPUREG {
		BYTE	cpudata[32];
		CPUSTAT_O	cpu;
	} cpureg;
	union	uniPPUREG {
		BYTE	ppudata[32];
		PPUSTAT	ppu;
	} ppureg;
	APUSTAT_O	apu;
} REGSTAT_O, *LPREGSTAT_O;

// ver 0x0200�Խ�
typedef	struct	tagREGSTAT {
	union	uniCPUREG {
		BYTE	cpudata[64];
		CPUSTAT	cpu;
	} cpureg;
	union	uniPPUREG {
		BYTE	ppudata[32];
		PPUSTAT	ppu;
	} ppureg;
} REGSTAT, *LPREGSTAT;


//
// ��ĠRAM Data
// ID "RAM DATA"
typedef	struct	tagRAMSTAT {
	BYTE	RAM[2*1024];	// Internal NES RAM
	BYTE	BGPAL[16];	// BG Palette
	BYTE	SPPAL[16];	// SP Palette
	BYTE	SPRAM[256];	// Sprite RAM
} RAMSTAT, *LPRAMSTAT;

//
// MMU Data
// ID "MMU DATA"
typedef	struct	tagMMUSTAT {
	BYTE	CPU_MEM_TYPE[8];
	WORD	CPU_MEM_PAGE[8];
	BYTE	PPU_MEM_TYPE[12];
	WORD	PPU_MEM_PAGE[12];
	BYTE	CRAM_USED[8];
} MMUSTAT, *LPMMUSTAT;

//
// Mapper Data
// ID "MMC DATA"
typedef	struct	tagMMCSTAT {
	BYTE	mmcdata[256];
} MMCSTAT, *LPMMCSTAT;

//
// Controler Data
// ID "CONTDATA"
typedef	struct	tagCTRSTAT {
	union uniCTRDATA {
		BYTE	ctrdata[32];
		CTRREG	ctr;
	} ctrreg;
} CTRSTAT, *LPCTRSTAT;

//
// Disk Image
// Ver0.24�ޤ�
// ID "DSIDE 0A","DSIDE 0B","DSIDE 1A","DSIDE 1B"
typedef	struct	tagDISKSTAT {
	BYTE	DiskTouch[16];
} DISKSTAT, *LPDISKSTAT;

// Ver0.30�Խ�
// ID "DISKDATA"
typedef	struct	tagDISKDATA {
	LONG	DifferentSize;
} DISKDATA, *LPDISKDATA;

// ���¤�Disk Save Image Fileʹ�ä���
// Ver0.24�ޤ�
typedef	struct	tagDISKIMGFILEHDR {	//  0123456789AB
	BYTE	ID[12];		// "VirtuaNES DI"
	WORD	BlockVersion;
	WORD	DiskNumber;
} DISKIMGFILEHDR, *LPDISKIMGFILEHDR;

typedef	struct	tagDISKIMGHDR {
	BYTE	ID[6];		// ID "SIDE0A","SIDE0B","SIDE1A","SIDE1B"
	BYTE	DiskTouch[16];
} DISKIMGHDR, *LPDISKIMGHDR;

// VirtuaNES version0.30�Խ���
typedef	struct	tagDISKFILEHDR {	//  0123456789AB
	BYTE	ID[12];		// "VirtuaNES DI"
	WORD	BlockVersion;	// 0x0200:0.30	0x0210:0.31
	WORD	Reserved;
	DWORD	ProgID;		// Program ID
	WORD	MakerID;	// Maker ID
	WORD	DiskNo;		// Disk��
	DWORD	DifferentSize;	// ���`��
} DISKFILEHDR, *LPDISKFILEHDR;

//
// Movie File
//
// VirtuaNES version0.60�Խ���
typedef	struct	tagMOVIEFILEHDR {
	BYTE	ID[12];			// "VirtuaNES MV"
	WORD	BlockVersion;		// Movie version 0x0300
	WORD	RecordVersion;		// Record version
	DWORD	Control;		// Control Pad
					// 76543210(Bit)
					// E---4321
					// |   |||+-- 1P Data
					// |   ||+--- 2P Data
					// |   |+---- 3P Data
					// |   +----- 4P Data
					// +--------- ׷ӛ��ֹ
					// ������Controler��1P��4P(�ɤ�Ǥ�����)�η���Key��
					// ȫ��ON�Εr���ΤΣ�Pad��Controler��Data�ˤʤ�
	DWORD	Ext0;			// ROM:Program CRC	FDS:Program ID
	WORD	Ext1;			// ROM:����		FDS:Maker ID
	WORD	Ext2;			// ROM:����		FDS:Diskö��
	DWORD	RecordTimes;		// ӛ�h����(ȡ��ֱ������)

	BYTE	RenderMethod;		// Rendering��ʽ
	BYTE	IRQtype;		// IRQ Type
	BYTE	FrameIRQ;		// FrameIRQ��ֹ
	BYTE	VideoMode;		// NTSC/PAL

	BYTE	reserved2[8];		// ��s

	LONG	StateStOffset;		// Movie start state offset
	LONG	StateEdOffset;		// Movie end state offset
	LONG	MovieOffset;		// Movie data offset
	LONG	MovieStep;		// Movie steps(Frame��)

	DWORD	CRC;			// ����Data�����CRC(���������ֹ)
} MOVIEFILEHDR, *LPMOVIEFILEHDR;

// Famtasia Movie....
typedef	struct	tagFMVHDR {
	BYTE	ID[4];			// "FMV^Z"
	BYTE	Control1;		// R???????	0:Reset�ᤫ��ӛ�h�� 1:;�Ф���ӛ�h
	BYTE	Control2;		// OT??????	O:1P��� T:2P���
	DWORD	Unknown1;
	WORD	RecordTimes;		// ӛ�h����-1
	DWORD	Unknown2;
	BYTE	szEmulators[0x40];	// ӛ�h����Emulator
	BYTE	szTitle    [0x40];	// Title
} FMVHDR, *LPFMVHDR;

// Nesticle Movie....
typedef	struct	tagNMVHDR {
	BYTE	ExRAM[0x2000];
	BYTE	S_RAM[0x0800];
	WORD	PC;
	BYTE	A;
	BYTE	P;
	BYTE	X;
	BYTE	Y;
	BYTE	SP;
	BYTE	OAM[0x0100];
	BYTE	VRAM[0x4000];
	BYTE	Other[0xC9];
	DWORD	ScanlineCycles;
	DWORD	VblankScanlines;
	DWORD	FrameScanlines;
	DWORD	VirtualFPS;
} NMVHDR, *LPNMVHDR;

#pragma pack( pop )

#endif	// !__STATE_INCLUDED__
